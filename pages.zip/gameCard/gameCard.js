const gameCardTemplate = document.createElement("template");
    gameCardTemplate.innerHTML = `
    <link rel="stylesheet" href="../webComponents/gameCard/gameCard.css">
    <link rel="stylesheet" href="../webComponents/tag/tag.css">

        <div class="gameCard">
    
            <img src="../assets/action_rpg_1.jpg" class="gameImage">
            
            <div class="infoContainer">
                <span class="header">
                    <h3>Titulo Juego</h3>
                    <h2>8</h2>
                    <h4>Desarrollador</h4>
                </span>
            </div>

            
                <div class="tagContainer">
                    <label class ="tagList" id="tagU">Action RPG</label>
                
                    <label class ="tagList" id="tagU">Action</label>
                </div>
            
        </div>
    `;
    
    class GameCard extends HTMLElement {
        constructor() {
            super();
            this.attachShadow({ mode: "open" });
            this.shadowRoot.appendChild(gameCardTemplate.content.cloneNode(true));
    
            // Elementos del shadow DOM
            this.gameImageElement = this.shadowRoot.querySelector(".gameImage");
            this.titleElement = this.shadowRoot.querySelector(".title");
            this.developerElement = this.shadowRoot.querySelector(".developer");
            this.scoreElement = this.shadowRoot.querySelector(".score");
            this.tagsElement = this.shadowRoot.querySelector(".tags");
        }
    
        // Setters para cada elemento de información
        setGameImage(imageUrl) {
            this.gameImageElement.style.backgroundImage = `url(${imageUrl})`;
        }
    
        setTitle(title) {
            this.titleElement.innerText = title;
        }
    
        setDeveloper(developer) {
            this.developerElement.innerText = developer;
        }
    
        setScore(score) {
            this.scoreElement.innerText = score;
        }
    
        setTags(tags) {
            const tagsU = this.shadowRoot.querySelector("#tagU");

            this.tagsElement.innerHTML = "";
            tags.forEach(tag => {
                const tagItem = document.createElement("tag-item");
                tagItem.setTagName(tag);
                this.tagsElement.appendChild(tagItem);
            });
        }
            /*
        setTagList(tags) {
                    const tagList = this.shadowRoot.querySelector("#tagList");
                
                    for (const tag in tags) {
                        for(const property in tags[tag]){
                            if(property == "name"){
                                const tagItem = document.createElement("tag-item");
                                // console.log(`${property}: ${game.tags[tag][property]}`);
                                tagItem.setTagName(tags[tag][property])
                                tagList.appendChild(tagItem);
                            }
                        }
                    }
                }//fin setTagList
            */

        
    }
    
    customElements.define("game-card", GameCard);

