
function getLogrosUser(){
    return $.ajax({
        url: '/api/logrosUser',
        method: 'GET',
        success: function (data) {
            console.log(data);
            //return data;
        },
        error: function (error) {
            console.error('Error al realizar la solicitud:', error.statusText);
        }
    });
}
