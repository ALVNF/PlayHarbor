const path = require('path');
const fs = require('fs');
const express = require('express');
const router = express.Router();
const { db } = require('../firebase'); // Importa db desde firebase.js
const { storage } = require('../firebase'); 
const { admin } = require('../firebase'); 
const { release } = require('os');
const socketIo = require('socket.io');

router.get('/login2', (req, res) => {
  res.send('Ruta de usuarios');
});

module.exports = router;

//luego meter esto en script JS, similar a funcion getinfo juego
router.get('/infoUser', async (req, res) => {
  try {
      const nombreUsuario = (req.query.nombre).toLowerCase();//Te pasan la consulta aqui
      const docRef = db.collection('users').doc(nombreUsuario);//Cambiar colección games por user y doc nombre usuario
      const snapshot = await docRef.get();
      if (snapshot.empty) {
          res.json({ message: "No se ha encontrado el usuario en cuestión" });
          return;
      }
      const datos = snapshot.data();
      //console.log(datos);

      const infoUsuario = {//seleccionamos datos que queremos
          name: datos.name,
          email: datos.email,
          exp: datos.exp,
          level: datos.level,
          developer: datos.developer,
          admin: datos.admin
      }
      console.log(infoUsuario);
      res.json({ datos: infoUsuario});

      

  } catch (error) {
      res.status(500).json({ message: 'Error al conectar con Firestore.', error: error.message });
  }
});