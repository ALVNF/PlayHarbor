 function obtenerURLImagen(juego,tipo) {
    console.log("Soy getImgsJuego()");
    /*try {
        
        var referencia = "";
        
        if(tipo == "profile"){
            referencia = storage.ref().child('/games/'+ juego +'/' + tipo + "/" + tipo);
        }else{
            referencia = storage.ref().child('/games/'+ juego +'/' + tipo + "/");
        }
        

        // Obtén la URL de descarga del archivo
        const url = await referencia.getDownloadURL();

        return url;
    } catch (error) {
        console.error('Error al obtener la URL de la imagen:', error);
        throw error;
    }*/
}