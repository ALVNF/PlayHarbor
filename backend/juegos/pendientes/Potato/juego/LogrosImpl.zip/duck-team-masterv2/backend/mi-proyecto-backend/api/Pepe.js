/Recupera los puntos de todos los usuarios para todos los juegos, en front ya se recupera usu actual/
async function getPuntosJuegos(tipoM) {
  const puntosTotalesPorJuego = {};
  try {
    const juegosSnapshot = await db.collection("games").get();
    if (juegosSnapshot.empty) {
      console.log("No existen juegos");
    } 

    //Itera sobre cada juego
    for (const juegoDoc of juegosSnapshot.docs) {
      const juegoId = juegoDoc.id;

      puntosTotalesPorJuego[juegoId] = {};

      //Obtiene los partidos del juego actual
      const partidosSnapshot = await juegoDoc.ref.collection("matches").where("type", "==", tipoM).get();

      //Itera sobre cada partido
      for (const partidoDoc of partidosSnapshot.docs) {
        // Obtiene los equipos del partido actual
        const equiposSnapshot = await partidoDoc.ref.collection("teams").get();

        //Itera sobre cada equipo
        for (const equipoDoc of equiposSnapshot.docs) {
          //Obtiene los puntajes del equipo actual
          const puntajesSnapshot = await equipoDoc.ref.collection("scores").get();
          for (const personaDoc of puntajesSnapshot.docs) {
            var jugadorId = personaDoc.id;
            var puntos = personaDoc.data().finalPoints
            if (!puntosTotalesPorJuego[juegoId][jugadorId]) {
              puntosTotalesPorJuego[juegoId][jugadorId] = 0;
            }

            puntosTotalesPorJuego[juegoId][jugadorId] += puntos;
          }
        }
      }
    }

    return puntosTotalesPorJuego;
  } catch (error) {
    console.error("Error al obtener los puntos por juego:", error);
    throw error;
  }
}







async function obtenerLogrosUsuario(nombreUsuario) {
  try {
    // Referencia al usuario y su colección de logros
    const userDocRef = db.collection('Users').doc(nombreUsuario);
    const logrosCollectionRef = userDocRef.collection('achievements');

    // Obtener los logros del usuario
    const logrosSnapshot = await logrosCollectionRef.get();
    logrosSnapshot.forEach(async logroDoc => {
      const nombreJuego = logroDoc.data().nombreJuego;

      // Referencia al juego y su colección de logros
      const juegosCollectionRef = db.collection('Achievements');
      const juegoDocRef = juegosCollectionRef.doc(nombreJuego);
      const logrosJuegoCollectionRef = juegoDocRef.collection('NombreDelLogro');

      // Obtener el logro específico del juego
      const logroJuegoSnapshot = await logrosJuegoCollectionRef.get();
      logroJuegoSnapshot.forEach(logroJuegoDoc => {
        const logro = logroJuegoDoc.data().NombreDelLogro;
        console.log(`Logro del juego "${nombreJuego}":`, logro);
        // Puedes hacer algo con el logro aquí
      });
    });
  } catch (error) {
    console.error('Error al obtener los logros del usuario:', error);
  }
}