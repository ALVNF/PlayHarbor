const path = require('path');
const fs = require('fs');
const express = require('express');
const router = express.Router();
const { db } = require('../firebase'); // Importa db desde firebase.js
const { storage } = require('../firebase'); 
const { admin } = require('../firebase'); 
const { release } = require('os');
const socketIo = require('socket.io');

const rutaWeb = "https://localhost:3000/logros/"

const bucket = admin.storage().bucket();

router.get('/datosLogro', async(req, res) => {//Funcionalidad para la obtención de logros de un juego DEPRECATED, revisar antes de borrar
    try{
        const nombreJuego = (req.query.nombre).toLowerCase();//Juego del que queremos obtener los logros
        const docRef = db.collection("achivements").doc("games").collection(nombreJuego);//Referencia a la colección de logros de un juego
        const snapshot = await docRef.get();//Obtenemos la colección de logros del juego
        
        if(snapshot.empty){
            res.json({message: "No se han encontrado logros para dicho juego"});
            return;
        }
        
        const logros = [];//array de logros
        snapshot.array.forEach(doc => {//datos de los logros
            logros.push(
                {
                    borderURL: doc.data().borderURL,
                    description: doc.data().description,
                    difficulty: doc.data().difficulty,
                    howToObtain: doc.data().howToObtain,
                    imageURL: doc.data().imageURL,
                    name: doc.data().name,
                    platformExp: doc.data().platformExp
                }
            );
            
            console.log(logros);
            res.json({ achivements: logros})

        });

        
    }catch(error){
        res.status(500).json({ message: 'Error al conectar con firestore', error: error.message })
    }
    
    

}

);

module.exports = router;//Exporta todas las rutas del router al server




router.get('/logrosUser', async (req, res) =>{//Funcionalidad para obtener logros y sus datos
    console.log("Boton testLogrosUsuarioPulsado");
    try{

        //--------------------------------------------------------------------------------------------------//
        //**************************************************************************************************//
        //************************Sección 1: Obtención de logros del usuario********************************//
        //**************************************************************************************************//
        //--------------------------------------------------------------------------------------------------//
        //CAMBIOS PENDIENTES:  cambiar "admin" por UsuarioBuscado

        //OJO: en un futuro el admin debe ser sustituido por nombreUser <-----
        const docRef =  db.collection('users').doc("admin").collection("achivementsByGame");
        const snapshot = await docRef.get();
        if(snapshot.empty){
            console.log("Logros no localizados");
            res.json({message: "No se han lozalizado logros"});
        }else{
            const listadoJuegos = [];//IMPORTANTE: Almacena los obtenidos por el USUARIO en función del juego
            let pos = 0;
            const listadoLogrosPorJuego = {};//Hashmap para almacenar juegos y sus logros
            snapshot.forEach((doc) => {//recoremos la colección de logros del usuario
                const datos = doc.data();//vamos mostrando cada doc de la colección
                const nombreJuego = doc.id;
                const LogrosJuego = Object.keys(datos);
                console.log("DOC ID: " + nombreJuego);//esto nos da el nombre del juego
                console.log(LogrosJuego);//esto otro nos da el nombre de los logros
                
                listadoLogrosPorJuego[nombreJuego] = LogrosJuego;//almacenamos los datos

                listadoJuegos[pos] = nombreJuego;//almacenamos juegos en lista de juegos
                pos++;//incrementamos en 1 la posición del array

            });
            console.log(listadoLogrosPorJuego);//Mostramos listado resultante por consola
            console.log(listadoJuegos);


            
        //--------------------------------------------------------------------------------------------------//
        //**************************************************************************************************//
        //************************Sección 2: Obtención de logros de cada juego******************************//
        //**************************************************************************************************//
        //--------------------------------------------------------------------------------------------------//


            if(!listadoLogrosPorJuego.empty){//Si el usuario tiene algún logro
                const ListaLogrosGenerales = [];//IMPORTANTE: Almacena los logros de un juego en específico con los campos de estos
                //OJO <-- esto tiene que ser iterativo, de forma que cuando esté en bucle el potatogame sera cambiado por NombreJuego




                const DocRefGames = db.collection("achievements").doc("games");
                const snapshotGames = await DocRefGames.get();
                const ListadoJuegosSnapshot = await DocRefGames.listCollections();
                
                if(snapshotGames.empty){
                    console.log("ERROR: No se localizan juegos en achievements");
                }else{
                    ListadoJuegosSnapshot.forEach(async collection => {//vamos recorriendo los juegos almacenados en el doc games
                        console.log("Juego: " + collection.id);



                        console.log("obteniendo logros de los juegos: ");
                        const DocRefAchivements = db.collection("achievements").doc("games").collection(collection.id);//obtenemos logros de potato games
                        const snapshotAchivements = await DocRefAchivements.get();
                        if(snapshotAchivements.empty){//si no está vacío
                            console.log("ERROR: no hay logros en achivements");
                            res.json({message: "No se han localizado logros"});
                        }else{
                            snapshotAchivements.forEach((doc) => {//Por cada logro(que debería ser un doc)
                                const datosLG = doc.data();
                                const nameJuegoLogro = doc.id;//Nombre del logro
                                const LogrosJuegoLogro = Object.keys(datosLG);//Nos debería dar los campos del logro
                                console.log("Nombre del Logro: " + nameJuegoLogro);
                                console.log(LogrosJuegoLogro);
        
                            });
        
                        }




                    });
                    


                    /*METEDURA DE PATA XD
                    snapshotGames.forEach((collection) => {
                        const DatosJuegos = collection.data();
                        const NameGame = Object.keys(DatosJuegos);
                        console.log(NameGame);
                        console.log(DatosJuegos);

                    });*/


                }


                //OJO: esta parte tiene que estar contenida dentro del código de arriba
                const DocRefAchivements = db.collection("achievements").doc("games").collection("potatoGame");//obtenemos logros de potato games
                const snapshotAchivements = await DocRefAchivements.get();
                if(snapshotAchivements.empty){//si no está vacío
                    console.log("ERROR: no hay logros en achivements");
                    res.json({message: "No se han localizado logros"});
                }else{
                    snapshotAchivements.forEach((doc) => {//Por cada logro(que debería ser un doc)
                        const datosLG = doc.data();
                        const nameJuegoLogro = doc.id;//Nombre del logro
                        const LogrosJuegoLogro = Object.keys(datosLG);//Nos debería dar los campos del logro
                        console.log("Nombre del Logro: " + nameJuegoLogro);
                        console.log(LogrosJuegoLogro);

                    });

                }


            }else{
                console.log("El usuario no tiene logros");
            }
            

        }

    }catch (error){
        console.log("Error"+ error);
        

    }
}

);
module.exports = router;