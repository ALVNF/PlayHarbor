const path = require('path');
const fs = require('fs');
const express = require('express');
const router = express.Router();
const { db } = require('../firebase'); // Importa db desde firebase.js
const { storage } = require('../firebase'); 
const { admin } = require('../firebase'); 
const { release } = require('os');
const socketIo = require('socket.io');

const rutaWeb = "https://localhost:3000/logros/"

const bucket = admin.storage().bucket();

router.get('/datosLogro', async(req, res) => {//Funcionalidad para la obtención de logros de un juego
    try{
        const nombreJuego = (req.query.nombre).toLowerCase();//Juego del que queremos obtener los logros
        const docRef = db.collection("achivements").doc("games").collection(nombreJuego);//Referencia a la colección de logros de un juego
        const snapshot = await docRef.get();//Obtenemos la colección de logros del juego
        
        if(snapshot.empty){
            res.json({message: "No se han encontrado logros para dicho juego"});
            return;
        }
        
        const logros = [];//array de logros
        snapshot.array.forEach(doc => {//datos de los logros
            logros.push(
                {
                    borderURL: doc.data().borderURL,
                    description: doc.data().description,
                    difficulty: doc.data().difficulty,
                    howToObtain: doc.data().howToObtain,
                    imageURL: doc.data().imageURL,
                    name: doc.data().name,
                    platformExp: doc.data().platformExp
                }
            );
            
            console.log(logros);
            res.json({ achivements: logros})

        });

        
    }catch(error){
        res.status(500).json({ message: 'Error al conectar con firestore', error: error.message })
    }
    
    

}

);

module.exports = router;//Exporta todas las rutas del router al server




router.get('/logrosUser', async (req, res) =>{
    console.log("Boton testLogrosUsuarioPulsado");
    try{
        //console.log("Esto está dentro del try");
        //const nombreUser = (req.query.nombre).toLocaleLowerCase();
        //OJO: en un futuro el admin debe ser sustituido por nombreUser <-----
        const docRef =  db.collection('users').doc("admin").collection("achivementsByGame");
        //const docRef =  db.collection('users').doc("admin");
        const snapshot = await docRef.get();
        if(snapshot.empty){
            console.log("Logros no localizados");
            res.json({message: "No se han lozalizado logros"});
        }else{
            const listadoJuegos = [];//IMPORTANTE: Almacena los obtenidos por el USUARIO en función del juego
            let pos = 0;
            const listadoLogrosPorJuego = {};//Hashmap para almacenar juegos y sus logros
            snapshot.forEach((doc) => {//recoremos la colección de logros del usuario
                const datos = doc.data();//vamos mostrando cada doc de la colección
                const nombreJuego = doc.id;
                const LogrosJuego = Object.keys(datos);
                //console.log(datos);//Mostramos en pantalla los datos
                console.log("DOC ID: " + nombreJuego);//esto nos da el nombre del juego
                console.log(LogrosJuego);//esto otro nos da el nombre de los logros
                
                listadoLogrosPorJuego[nombreJuego] = LogrosJuego;//almacenamos los datos

                listadoJuegos[pos] = nombreJuego;//almacenamos juegos en lista de juegos
                pos++;//incrementamos en 1 la posición del array

            });
            console.log(listadoLogrosPorJuego);//Mostramos listado resultante por consola
            console.log(listadoJuegos);

            if(!listadoLogrosPorJuego.empty){//Si el usuario tiene algún logro

                const ListaLogrosGenerales = [];//IMPORTANTE: Almacena los logros de un juego en específico con los campos de estos
                //console.log("Entrando en busqueda de logros generales")
                //Obtenemos datos desde el listado de logros
                //const DocRefAchivements = db.collection("achivements").doc("games");
                //const snapshotAchivements = await constDocRefAchivements.get();
                //OJO <-- esto tiene que ser iterativo, de forma que cuando esté en bucle el potatogame sera cambiado por NombreJuego
                const DocRefAchivements = db.collection("achievements").doc("games").collection("potatoGame");//obtenemos logros de potato games
                const snapshotAchivements = await DocRefAchivements.get();
                console.log("PreIF");
                if(snapshotAchivements.empty){//si no está vacío
                    console.log("ERROR: no hay logros en achivements");
                    res.json({message: "No se han localizado logros"});
                }else{
                    console.log("Dentro del Else");
                    snapshotAchivements.forEach((doc) => {//Por cada logro(que debería ser un doc)
                        const datosLG = doc.data();
                        const nameJuegoLogro = doc.id;//Nombre del logro
                        const LogrosJuegoLogro = Object.keys(datosLG);//Nos debería dar los campos del logro
                        console.log("Nombre del Logro: " + nameJuegoLogro);
                        console.log(LogrosJuegoLogro);

                    });
                    //console.log(snapshotAchivements);

                }


            }else{
                console.log("El usuario no tiene logros");
            }
            

        }

    }catch (error){
        console.log("Error"+ error);
        

    }
}

);
module.exports = router;








//Función para obtener los logros de un usuario determinado
//IN: Nombre del usuario
//OUT: Logros del usuario


//Idea general:
//1. buscamos el usuario y los logros por juego que tenga
//2. si no está vacío procedemos a almacenar los nombres de los logros en una lista. 
//3. Comenzamos buscamos en la colección de achivements los logros usando la lista obtenida
//4. Segun vayamos obteniendo los logros los iremos almacenando en otra lista
//5. Al finalizar se devuelve el listado en cuestión

async function obtenerLogrosUsuario(usuario){
    const logrosUser = {}
    const arrayLogrosJuego = {}
    //Obtenemos usuario desde la base de datos


    try{
        const snapshotUser = await db.collection("Users").doc(usuario).collection("achivementsByGame").get();//Obtenemos los logros de un usuario(1.)
        



        for(const juego of snapshotUser.docs){
            console.log(juego.id);
        }


        //Comprobamos que el usuario existe o no está vacío:
        if(snapshotUser.empty){//Comprobamos si los logros del usuario están vacíos

            console.log("Usuario no existente");//salida de terminal
        
        }else{//si no está vacío procedemos a rastrear los logros

        }
    }catch(error){
        
    }


}


/*
//Implementar obtención de logros obtenidos por un usuario
async function getLogrosUsuario(usuario){
    const logrosUsuario = {};//array de logros localizados
    try{

        const snapshotLogros = await db.collection("achivements").doc("games").get();//Buscamos los logros de un juego
        //const snapshotUserLogros = await db.collection("users").get();
        if(snapshotUserLogros.empty){
            console.log("No hay logros")
        }

        for(const logroObtenido of snapshotLogros.collection){
            



        }

    }catch(error){

    }
}*/